import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import '../models/move.dart';
import '../models/pos.dart';
import '../controllers/course_controller.dart';
import '../widgets/checkers_board.dart';

class CoursePlayerScreen extends StatefulWidget {
  final String jsonAssetPath;

  const CoursePlayerScreen({Key? key, required this.jsonAssetPath}) : super(key: key);

  @override
  State<CoursePlayerScreen> createState() => _CoursePlayerScreenState();
}

class _CoursePlayerScreenState extends State<CoursePlayerScreen> {
  late CourseController controller;
  bool isLoading = true;
  String errorMessage = '';

  @override
  void initState() {
    super.initState();
    _loadCourse();
  }

  Future<void> _loadCourse() async {
    try {
      final jsonString = await rootBundle.loadString(widget.jsonAssetPath);
      final List<dynamic> steps = json.decode(jsonString);
      setState(() {
        controller = CourseController(steps: steps);
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        errorMessage = 'Failed to load course: $e';
        isLoading = false;
      });
    }
  }

  void _onUserMove(Pos from, Pos to) {
    final userMove = Move(from, to);
    final correct = controller.checkUserMove(userMove);

    if (correct) {
      setState(() {
        errorMessage = '';
      });
      final opponentMove = controller.makeOpponentMove();
      if (opponentMove != null) {
        // TODO: обновить доску ходом оппонента
        // для этого добавь механизм обновления доски и состояния в CheckersBoard
      }
    } else {
      setState(() {
        errorMessage = 'Неправильный ход. Попробуйте снова.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (errorMessage.isNotEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('Course Player')),
        body: Center(child: Text(errorMessage)),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Course Player')),
      body: Column(
        children: [
          Expanded(
            child: CheckersBoard(
              onUserMove: _onUserMove,
              // передай сюда текущие данные для отображения, например ход оппонента
            ),
          ),
          if (errorMessage.isNotEmpty)
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(errorMessage, style: const TextStyle(color: Colors.red)),
            ),
        ],
      ),
    );
  }
}
