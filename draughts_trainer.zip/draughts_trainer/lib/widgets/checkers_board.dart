import 'package:flutter/material.dart';
import '../models/pos.dart';

typedef OnUserMove = void Function(Pos from, Pos to);

class CheckersBoard extends StatefulWidget {
  final OnUserMove onUserMove;

  const CheckersBoard({Key? key, required this.onUserMove}) : super(key: key);

  @override
  _CheckersBoardState createState() => _CheckersBoardState();
}

class _CheckersBoardState extends State<CheckersBoard> {
  static const int size = 8;

  // Для примера: 0 - пусто, 1 - белая шашка, 2 - черная шашка
  List<List<int>> board = List.generate(
    size,
    (y) => List.generate(size, (x) {
      if ((x + y) % 2 == 1 && y < 3) return 2; // черные шашки сверху
      if ((x + y) % 2 == 1 && y > 4) return 1; // белые снизу
      return 0;
    }),
  );

  Pos? selected;

  void _onSquareTap(int x, int y) {
    if (selected == null) {
      if (board[y][x] != 0) {
        setState(() {
          selected = Pos(x, y);
        });
      }
    } else {
      final from = selected!;
      final to = Pos(x, y);
      if (from.x == to.x && from.y == to.y) {
        setState(() {
          selected = null;
        });
        return;
      }
      // Передаем ход наверх
      widget.onUserMove(from, to);
      setState(() {
        selected = null;
      });
    }
  }

  Widget _buildSquare(int x, int y) {
    final bool isDark = (x + y) % 2 == 1;
    final color = isDark ? Colors.brown[700] : Colors.brown[300];

    Widget? piece;
    if (board[y][x] == 1) {
      piece = _buildPiece(Colors.white);
    } else if (board[y][x] == 2) {
      piece = _buildPiece(Colors.black);
    }

    final isSelected = selected != null && selected!.x == x && selected!.y == y;

    return GestureDetector(
      onTap: () => _onSquareTap(x, y),
      child: Container(
        decoration: BoxDecoration(
          color: isSelected ? Colors.yellow : color,
        ),
        child: Center(child: piece),
      ),
    );
  }

  Widget _buildPiece(Color color) {
    return Container(
      width: 30,
      height: 30,
      decoration: BoxDecoration(
        color: color,
        shape: BoxShape.circle,
        border: Border.all(color: Colors.black),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 1,
      child: GridView.builder(
        itemCount: size * size,
        gridDelegate:
            const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: size),
        itemBuilder: (context, index) {
          final x = index % size;
          final y = index ~/ size;
          return _buildSquare(x, y);
        },
      ),
    );
  }
}
