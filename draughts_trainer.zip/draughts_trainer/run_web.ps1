# Очищаем кэш и старую сборку
flutter clean

# Обновляем зависимости
flutter pub get

# Запускаем проект в Chrome
flutter run -d chrome
