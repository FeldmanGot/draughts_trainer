package com.example.draughts_trainer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
